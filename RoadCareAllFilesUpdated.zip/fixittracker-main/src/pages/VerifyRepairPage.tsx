
import VerifyRepair from "@/components/reports/VerifyRepair";

const VerifyRepairPage = () => {
  return <VerifyRepair />;
};

export default VerifyRepairPage;
